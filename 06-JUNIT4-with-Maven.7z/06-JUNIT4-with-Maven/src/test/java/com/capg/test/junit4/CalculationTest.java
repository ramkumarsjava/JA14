package com.capg.test.junit4;


	
import static org.junit.Assert.assertEquals;
import org.junit.Test;
	public class CalculationTest
	
	  {		
		@Test 
		public void testAdd() 
        	{  
		    try {
		   assertEquals(20, new Calculation().addition(10,10));
		   
		   
		   
		 
		   } catch (Exception e) {
			System.out.println(e);
		 } 
		
		  
	} 
	
		
	}

package com.capg.test.junit4;

public class Calculation {
	
	public int addition(int a,int b)
	{    int z=a+b;
		return z;
	}
	public int substraction(int x,int y)
	{    
		return  x-y;
	}
	public int multiplication(int d1,int d2)
	{    
		return  d1*d2;
	}
	public int division(int d1,int d2)
	{    
		return  d1/d2;
	}

	 
}

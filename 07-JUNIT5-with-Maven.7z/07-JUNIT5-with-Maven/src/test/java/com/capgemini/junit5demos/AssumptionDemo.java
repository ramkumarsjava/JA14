package com.capgemini.junit5demos;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

public class AssumptionDemo {
		@Test
	    void testOnDev() 
		{
			System.setProperty("ENV", "DEV");
	        Assumptions.assumeTrue("ENV".equals(System.getProperty("ABC")));
	        //remainder of test will proceed
	    }
		
		@Test
	    void testOnProd() 
		{
			System.setProperty("ENV", "PROD");
	        Assumptions.assumeTrue("ENV".equals(System.getProperty("ENV")), AssumptionDemo::message);
	        //remainder of test will be aborted
	    }
		
		private static String message () {
			return "TEST Execution Failed :: ";
		}
}
